package com.example.emissiontest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.emissiontest.adapters.fragmentsapapter;
import com.example.emissiontest.databinding.ActivityMainBinding;
import com.example.emissiontest.models.loginfo;
import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    String status;
    FirebaseAuth auth;

    ArrayList<loginfo> loginfoArrayList;

    String device_number, currentDate, currentTime;

    int count = 10;

    String currentDate1, currentTime1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        status = getIntent().getStringExtra("STATUS");
        auth = FirebaseAuth.getInstance();

        binding.viewPager.setAdapter(new fragmentsapapter(getSupportFragmentManager()));
        binding.tablayout.setupWithViewPager(binding.viewPager);
        binding.tablayout.getTabAt(0).setIcon(R.drawable.ic_batter_icon);
        binding.tablayout.getTabAt(1).setIcon(R.drawable.ic_smoke);
        binding.tablayout.getTabAt(2).setIcon(R.drawable.ic_log_file_format);

        SharedPreferences sharedPreferences = getSharedPreferences("phonenumber", 0);
        device_number = sharedPreferences.getString("Device_number", String.valueOf(0));
        currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
//        timerfunctionfaulty();


    }
    private void statusfaulty(){



        loginfoArrayList =  Preconfig.readListFromPref(MainActivity.this);
        if(loginfoArrayList == null){
            loginfoArrayList = new ArrayList<>();
        }

        ContentResolver cResolver = getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);
        smsInboxCursor.moveToFirst();

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");

        do {

            String body, sender, date, time;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody).toString();
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (device_number.equals(sender)){
                String[] smsbody = body.split("\n");
                if(smsbody[0].matches("FAULTY_VG") && currentDate1.matches(date) && currentTime1.compareTo(time)< 0  ){
                    if(smsbody.length > 1 ){
                        String[] buffer = smsbody[1].split(" ");

                        String[] buffer2 = buffer[1].split("");
                        String val = "";
                        for(int i=1; i < buffer2.length-1; i++){
                            val = val + buffer2[i];
                        }
                        Log.d("Voltage----->>>>>>", val);


//                        String[] buffer3 = smsbody[2].split("");
                        String val1 = "0.00";
//                        for(int i=4; i< buffer3.length-4; i++){
//                            val1 = val1 + buffer3[i];
//                        }
//                        Log.d("CO----->>>>>>", val1);
                        SharedPreferences sharedPreferences = getSharedPreferences("COvalue", 0);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("CO", val1);
                        loginfo object = new loginfo(date, time, val, val1, "yes");
                        loginfoArrayList.add(object);
                        Preconfig.writeListInPref(MainActivity.this, loginfoArrayList);
                        editor.commit();
                    }

                }

            }
        }while (smsInboxCursor.moveToNext());
    }

    private void timerfunctionfaulty() {

        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                    currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                    statusfaulty();
                }
                else{
                    count = count - 1;
                }

            }

            @Override
            public void onFinish() {
                timerfunctionfaulty();
            }
        }.start();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.edit_device) {

            Intent intent = new Intent(MainActivity.this, Editdevice.class);
            startActivity(intent);
            return true;
        }


        if (id == R.id.logout) {

            auth.signOut();
            Intent intent = new Intent(MainActivity.this, Splashscreen.class);
            startActivity(intent);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public Bundle getMyData() {
        Bundle bundle = new Bundle();
        bundle.putString("status", status);
        return bundle;
    }
    public Bundle getMyvalue() {
        Bundle bundle = new Bundle();
        bundle.putString("status", status);
        return bundle;
    }
}