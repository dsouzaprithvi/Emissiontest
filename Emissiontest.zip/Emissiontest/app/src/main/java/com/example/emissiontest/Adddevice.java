package com.example.emissiontest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Adddevice extends AppCompatActivity {

    Button adddevice;
    String device_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adddevice);

        adddevice = findViewById(R.id.add_device);

        SharedPreferences sharedPreferences = getSharedPreferences("phonenumber", 0);
        device_number = sharedPreferences.getString("Device_number", String.valueOf(0));

        if(!device_number.equals("0")){
            Intent intent = new Intent(Adddevice.this, MainActivity.class);
            intent.putExtra("STATUS","connected");
            startActivity(intent);
            finish();
        }


        adddevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Adddevice.this, Adding_device.class));
                finish();
            }
        });
    }
}