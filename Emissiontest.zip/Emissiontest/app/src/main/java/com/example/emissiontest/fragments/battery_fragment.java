package com.example.emissiontest.fragments;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.CountDownTimer;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.ekn.gruzer.gaugelibrary.HalfGauge;
import com.ekn.gruzer.gaugelibrary.Range;
import com.example.emissiontest.Adding_device;
import com.example.emissiontest.MainActivity;
import com.example.emissiontest.Preconfig;
import com.example.emissiontest.R;
import com.example.emissiontest.models.loginfo;
import com.ntt.customgaugeview.library.GaugeView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


public class battery_fragment extends Fragment {


    ImageView status_icon;
    TextView status, value;
    String device_number, currentDate, currentTime;
    Button check;
    ProgressBar progressBar;
    int count = 10;
    int flag = 0;
    GaugeView gaugeView;

    ArrayList<loginfo> loginfoArrayList;


    public battery_fragment() {
        // Required empty public constructor
    }






    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_battery_fragment, container, false);

        gaugeView = view.findViewById(R.id.gauge_view);
        status = view.findViewById(R.id.status);
        status_icon = view.findViewById(R.id.status_icon);
        check = view.findViewById(R.id.check_value);
        progressBar = view.findViewById(R.id.progressbar_check);
        value = view.findViewById(R.id.value);



        MainActivity mainActivity = (MainActivity) getActivity();

        Bundle bundle = mainActivity.getMyData();
        if(bundle.getString("status").matches("connected")){
            status.setText("CONNECTED");
            status_icon.setImageDrawable(getResources().getDrawable(R.drawable.ic_connected));
        }

        SharedPreferences sharedPreferences = getContext().getSharedPreferences("phonenumber", 0);
        device_number = sharedPreferences.getString("Device_number", String.valueOf(0));


//        timerfunctionfaulty();


        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = "STATUS";
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(device_number, null, message, null, null);
                flag = 0;
                currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                check.setVisibility(View.INVISIBLE);
                progressBar.setVisibility(View.VISIBLE);
                timerfunction();

            }
        });





        return view;
    }

    private void status(){

        loginfoArrayList =  Preconfig.readListFromPref(getContext());
        if(loginfoArrayList == null){
            loginfoArrayList = new ArrayList<>();
        }

        ContentResolver cResolver = getActivity().getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);
        smsInboxCursor.moveToFirst();

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");

        do {

            String body, sender, date, time;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody).toString();
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (device_number.equals(sender)){
                String[] smsbody = body.split("\n");
                if(smsbody[0].matches("STATUS") && currentDate.matches(date) && currentTime.compareTo(time)< 0 ){
                    if(smsbody.length > 1 ) {
                        String[] buffer = smsbody[1].split(" ");

                        String[] buffer2 = buffer[1].split("");
                        String val = "";
                        for(int i=1; i < buffer2.length-1; i++){
                            val = val + buffer2[i];
                        }
                        Log.d("Voltage----->>>>>>", val);
                        gaugeView.setTargetValue(Float.parseFloat(val));
                        value.setText(val);

                        String[] buffer3 = smsbody[2].split("");
                        String val1 = "";
                        for(int i=4; i< buffer3.length-4; i++){
                            val1 = val1 + buffer3[i];
                        }
                        Log.d("CO----->>>>>>", val1);
                        SharedPreferences sharedPreferences = getContext().getSharedPreferences("COvalue", 0);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("CO", val1);
                        loginfo object = new loginfo(date, time, val, val1, "no");
                        loginfoArrayList.add(object);
                        Preconfig.writeListInPref(getContext(), loginfoArrayList);
                        editor.commit();
                        flag = 1;
                    }

                }

            }
        }while (smsInboxCursor.moveToNext());
    }

    private void statusfaulty(){

        String currentDate1 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        String currentTime1 = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

//        loginfoArrayList =  Preconfig.readListFromPref(getContext());
//        if(loginfoArrayList == null){
//            loginfoArrayList = new ArrayList<>();
//        }

        ContentResolver cResolver = getActivity().getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);
        smsInboxCursor.moveToFirst();

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");

        do {

            String body, sender, date, time;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody).toString();
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (device_number.equals(sender)){
                String[] smsbody = body.split("\n");
                if(smsbody[0].matches("FAULTY_VG") && currentDate1.matches(date) && currentTime1.compareTo(time)< 0  ){
                    if(smsbody.length > 1 ){
                        String[] buffer = smsbody[1].split(" ");

                        String[] buffer2 = buffer[1].split("");
                        String val = "";
                        for(int i=1; i < buffer2.length-1; i++){
                            val = val + buffer2[i];
                        }
                        Log.d("Voltage----->>>>>>", val);
                        gaugeView.setTargetValue(Float.parseFloat(val));
                        value.setText(val);

//                        String[] buffer3 = smsbody[2].split("");
                        String val1 = "0.00";
//                        for(int i=4; i< buffer3.length-4; i++){
//                            val1 = val1 + buffer3[i];
//                        }
//                        Log.d("CO----->>>>>>", val1);
                        SharedPreferences sharedPreferences = getContext().getSharedPreferences("COvalue", 0);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("CO", val1);
                        loginfo object = new loginfo(date, time, val, val1, "yes");
                        loginfoArrayList.add(object);
                        Preconfig.writeListInPref(getContext(), loginfoArrayList);
                        editor.commit();
                    }

                }

            }
        }while (smsInboxCursor.moveToNext());
    }


    private void timerfunction() {
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    status();
                }
                else{
                    count = count - 1;
                }
                if(flag == 1){
                    cancel();
                    check.setVisibility(View.VISIBLE);
                    progressBar.setVisibility(View.INVISIBLE);
                }


            }

            @Override
            public void onFinish() {
                check.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.INVISIBLE);

            }
        }.start();
    }
    private void timerfunctionfaulty() {
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    statusfaulty();
                }
                else{
                    count = count - 1;
                }

            }

            @Override
            public void onFinish() {
               timerfunctionfaulty();
            }
        }.start();
    }
}