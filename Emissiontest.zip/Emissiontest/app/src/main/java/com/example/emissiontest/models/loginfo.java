package com.example.emissiontest.models;

public class loginfo {


    String date, time, voltage, co;


    public loginfo(String date, String time, String voltage, String co) {
        this.date = date;
        this.time = time;
        this.voltage = voltage;
        this.co = co;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getVoltage() {
        return voltage;
    }

    public void setVoltage(String voltage) {
        this.voltage = voltage;
    }

    public String getCo() {
        return co;
    }

    public void setCo(String co) {
        this.co = co;
    }
}
