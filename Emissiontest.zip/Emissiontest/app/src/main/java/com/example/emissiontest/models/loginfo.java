package com.example.emissiontest.models;

public class loginfo {


    String date, time, voltage, co, alert;


    public loginfo(String date, String time, String voltage, String co, String alert) {
        this.date = date;
        this.time = time;
        this.voltage = voltage;
        this.co = co;
        this.alert = alert;
    }

    public String getDate() {
        return date;
    }

    public String getAlert() {
        return alert;
    }

    public void setAlert(String alert) {
        this.alert = alert;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getVoltage() {
        return voltage;
    }

    public void setVoltage(String voltage) {
        this.voltage = voltage;
    }

    public String getCo() {
        return co;
    }

    public void setCo(String co) {
        this.co = co;
    }
}
