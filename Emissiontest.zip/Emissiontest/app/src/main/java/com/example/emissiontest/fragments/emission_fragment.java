package com.example.emissiontest.fragments;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.ekn.gruzer.gaugelibrary.ArcGauge;
import com.ekn.gruzer.gaugelibrary.Range;
import com.example.emissiontest.MainActivity;
import com.example.emissiontest.R;
import com.ntt.customgaugeview.library.GaugeView;


public class emission_fragment extends Fragment {


    ImageView status_icon;
    TextView status, value;
    Button check;
    GaugeView gaugeView;


    public emission_fragment() {
        // Required empty public constructor
    }





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_emission_fragment, container, false);

        status = view.findViewById(R.id.status);
        status_icon = view.findViewById(R.id.status_icon);
        value = view.findViewById(R.id.value);
        check = view.findViewById(R.id.check_value);
        gaugeView = view.findViewById(R.id.gauge_view);

        MainActivity mainActivity = (MainActivity) getActivity();

        Bundle bundle = mainActivity.getMyData();
        if(bundle.getString("status").matches("connected")){
            status.setText("CONNECTED");
            status_icon.setImageDrawable(getResources().getDrawable(R.drawable.ic_connected));
        }
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                MainActivity mainActivity = (MainActivity) getActivity();
//
//                SharedPreferences sharedPreferences = getContext().getSharedPreferences("COvalue", 0);
//                String val = sharedPreferences.getString("CO", String.valueOf(0));
//                Log.i("CO--------LL>>>",val);
//                gaugeView.setTargetValue(Float.parseFloat(val));
//                value.setText(val);

            }
        });








        return view;
    }
}