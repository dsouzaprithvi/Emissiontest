package com.example.emissiontest;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;


@SuppressLint("CustomSplashScreen")
public class Splashscreen extends AppCompatActivity {

    //duration for splash screen
    public static int SPLASH_SCREEN = 4000;


    //Variables
    Animation topanim, bottomanim;
    ImageView logoimage;
    TextView textView1, textView2, textView3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);


        //Animations
        topanim = AnimationUtils.loadAnimation(this, R.anim.top_animation);
        bottomanim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);


        //hooks
        logoimage = findViewById(R.id.logo);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);

        //add animation
        logoimage.setAnimation(topanim);
        textView1.setAnimation(topanim);
        textView2.setAnimation(topanim);
        textView3.setAnimation(topanim);



        //after animation is completed going to next activity
        new Handler().postDelayed(() -> {

            Intent intent = new Intent(Splashscreen.this, otpscreen.class);
            startActivity(intent);
            finish();

        },SPLASH_SCREEN);
    }
}