package com.example.emissiontest.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.emissiontest.Preconfig;
import com.example.emissiontest.R;
import com.example.emissiontest.adapters.logadapter;
import com.example.emissiontest.models.loginfo;

import java.util.ArrayList;


public class hystory_fragment extends Fragment {

    RecyclerView recyclerView;
    logadapter adapter;
    ArrayList<loginfo> logholder;

    Button refresh, delete;

    public hystory_fragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_hystory_fragment, container, false);
        adapter = new logadapter(logholder, getContext());


        refresh = view.findViewById(R.id.refresh);
        delete = view.findViewById(R.id.delete);
        recyclerView = view.findViewById(R.id.logs);


        updateview();

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                updateview();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                logholder = new ArrayList<>();
//                Preconfig.writeListInPref(getContext(), logholder);
//                updateview();
            }
        });



        return view;
    }

    private void updateview() {

        logholder = Preconfig.readListFromPref(getContext());
        if(logholder == null){
            logholder = new ArrayList<>();
        }
        loginfo obj = new loginfo("12-12-2022", "12:12:12", "12.00", "1.29");
        logholder.add(obj);
        adapter = new logadapter(logholder, getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
    }
}