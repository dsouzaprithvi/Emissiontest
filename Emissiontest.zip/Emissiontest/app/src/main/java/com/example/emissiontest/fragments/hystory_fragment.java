package com.example.emissiontest.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.emissiontest.Preconfig;
import com.example.emissiontest.R;
import com.example.emissiontest.adapters.logadapter;
import com.example.emissiontest.models.loginfo;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;


public class hystory_fragment extends Fragment {

    RecyclerView recyclerView;
    logadapter adapter;
    ArrayList<loginfo> logholder;

    Button refresh, delete, export;

    public hystory_fragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_hystory_fragment, container, false);
        adapter = new logadapter(logholder, getContext());


        refresh = view.findViewById(R.id.refresh);
        delete = view.findViewById(R.id.delete);
        recyclerView = view.findViewById(R.id.logs);
        export = view.findViewById(R.id.export);


        updateview();

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateview();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                logholder.clear();
                Preconfig.writeListInPref(getContext(), logholder);
                updateview();
            }
        });

        export.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createExcelSheet();
            }
        });



        return view;
    }

    private void updateview() {

        logholder = Preconfig.readListFromPref(getContext());
        if(logholder == null){
            logholder = new ArrayList<>();
        }
        adapter = new logadapter(logholder, getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
    }

    private void createExcelSheet()
    {
        String Fnamexls="excelSheet"+System.currentTimeMillis()+ ".xls";
        File sdCard = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File directory = new File (sdCard.getAbsolutePath() + "/newfolder");
        directory.mkdirs();
        File file = new File(directory, Fnamexls);

        WorkbookSettings wbSettings = new WorkbookSettings();

        wbSettings.setLocale(new Locale("en", "EN"));

        WritableWorkbook workbook;

        logholder = Preconfig.readListFromPref(getContext());
        try {
            int a = 1;
            workbook = Workbook.createWorkbook(file, wbSettings);
            //workbook.createSheet("Report", 0);
            WritableSheet sheet = workbook.createSheet("First Sheet", 0);
            Label label = new Label(2, 0, "CO");
            Label label1 = new Label(1,0,"Volatge");
            Label label0 = new Label(0,0,"DateTime");
            Label label3 = new Label(3,0,"Alert");
            Label label5 ;
            try {
                sheet.addCell(label);
                sheet.addCell(label1);
                sheet.addCell(label0);
                sheet.addCell(label3);

                for (int i = 0; i < logholder.size(); i++ ) {

                    String datetime = logholder.get(i).getDate() + " " + logholder.get(i).getTime();
                    String Voltage = logholder.get(i).getVoltage();
                    String co = logholder.get(i).getCo();

                    Float voltage = Float.valueOf(Voltage);
                    Float Co = Float.valueOf(co);




                    Log.i("ASFDGHASFHG->>>",datetime + Voltage + co);

                    Label label10 = new Label(0, i+1, datetime);
                    Label label11 = new Label(1, i+1, Voltage);
                    Label label12 = new Label(2, i+1, co);
                    Label label13;
                    if (voltage < 7.50 && Co > 2.50) {
                        label13 = new Label(3, i + 1, "Voltage is low and CO is more");
                    } else if (Co > 2.50) {
                        label13 = new Label(3, i + 1, "CO is more");
                    } else if (voltage < 7.50 ) {
                        label13 = new Label(3, i + 1, "Voltage is low");
                    } else {
                        label13 = new Label(3, i + 1, "Normal");
                    }

                    sheet.addCell(label10);
                    sheet.addCell(label11);
                    sheet.addCell(label12);
                    sheet.addCell(label13);

                }
            } catch (RowsExceededException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (WriteException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }


            workbook.write();
            try {
                workbook.close();
                Toast.makeText(getContext(), "Excel Sheet Created", Toast.LENGTH_SHORT).show();
            } catch (WriteException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            //createExcel(excelSheet);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }



    }
}