package com.example.emissiontest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import com.google.android.material.textfield.TextInputLayout;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Adding_device extends AppCompatActivity {

    Button add_device;
    ProgressBar progressBar;
    TextInputLayout device_number, user_number;
    String phone, currentDate, currentTime, mobnumber;
    int count = 10;
    int flag = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_device);

        add_device = findViewById(R.id.add);
        device_number = findViewById(R.id.device_number);
        user_number = findViewById(R.id.user_number);
        progressBar = findViewById(R.id.progressbar_add_device);


        add_device.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!validate_text(device_number) | !validate_text(user_number)){
                    return;
                }
                Intent intent = new Intent(Adding_device.this, MainActivity.class);
                intent.putExtra("STATUS","connected");
                startActivity(intent);
                finish();
//                currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
//                currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
//                phone = device_number.getEditText().getText().toString();
//                mobnumber = user_number.getEditText().getText().toString();
//                String message = "ADMIN*"+user_number.getEditText().getText().toString()+"*"
//                        +device_number.getEditText().getText().toString()+"*#";
//                SmsManager smsManager = SmsManager.getDefault();
//                smsManager.sendTextMessage(phone, null, message, null, null);
//                progressBar.setVisibility(View.VISIBLE);
//                add_device.setVisibility(View.INVISIBLE);
//                timerfunction();
            }
        });
    }

    private void status(){
        ContentResolver cResolver = getContentResolver();
        Cursor smsInboxCursor = cResolver.query(Uri.parse("content://sms/inbox"),
                null ,null, null, null);
        smsInboxCursor.moveToFirst();

        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        int indexDate = smsInboxCursor.getColumnIndex("date");
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");

        do {

            String body, sender, date, time;
            sender = smsInboxCursor.getString(indexAddress);
            body = smsInboxCursor.getString(indexBody).toString();
            date = df.format(smsInboxCursor.getLong(indexDate));
            time = tf.format(smsInboxCursor.getLong(indexDate));


            if (phone.equals(sender)){
                String[] smsbody = body.split("\n");
                if(smsbody[0].matches("STATUS") && currentDate.matches(date) && currentTime.compareTo(time)<0 ){
                    Intent intent = new Intent(Adding_device.this, MainActivity.class);
                    intent.putExtra("STATUS","connected");
                    SharedPreferences sharedPreferences = getSharedPreferences("phonenumber", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("Device_number", phone);
                    editor.putString("User_number", mobnumber);
                    editor.commit();
                    startActivity(intent);
                    flag = 1;
                    finish();
                }

            }
        }while (smsInboxCursor.moveToNext());
    }


    private void timerfunction() {
        long duration = TimeUnit.MINUTES.toMillis(1);
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {
                String sDuration = String.format(Locale.ENGLISH, "%02d"
                        , TimeUnit.MILLISECONDS.toSeconds(l)
                        , TimeUnit.MILLISECONDS.toSeconds(l) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(1)));
                String c = Integer.toString(count);
                Log.d("COUNT-------->", c);
                if (count == 0) {
                    count = 10;
                    status();
                }
                else{
                    count = count - 1;
                }
                if(flag == 1){
                    cancel();
                }

            }

            @Override
            public void onFinish() {

            }
        }.start();


    }

    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        }else if(val.length() < 13){
            id.setError("Invalid number");
            return false;
        }
        else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }
}