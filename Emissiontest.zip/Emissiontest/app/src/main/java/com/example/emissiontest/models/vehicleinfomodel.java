package com.example.emissiontest.models;

public class vehicleinfomodel {

    String name, vehicleno, mobno, rcno, adharno;

    public vehicleinfomodel() {
    }



    public vehicleinfomodel(String name, String vehicleno, String mobno, String rcno, String adharno) {
        this.name = name;
        this.vehicleno = vehicleno;
        this.mobno = mobno;
        this.rcno = rcno;
        this.adharno = adharno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVehicleno() {
        return vehicleno;
    }

    public void setVehicleno(String vehicleno) {
        this.vehicleno = vehicleno;
    }

    public String getMobno() {
        return mobno;
    }

    public void setMobno(String mobno) {
        this.mobno = mobno;
    }

    public String getRcno() {
        return rcno;
    }

    public void setRcno(String rcno) {
        this.rcno = rcno;
    }

    public String getAdharno() {
        return adharno;
    }

    public void setAdharno(String adharno) {
        this.adharno = adharno;
    }
}

