package com.example.emissiontest.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.emissiontest.R;
import com.example.emissiontest.models.loginfo;
import com.example.emissiontest.models.vehicleinfomodel;

import java.util.ArrayList;

public class logadapter extends RecyclerView.Adapter<logadapter.logViewholder>{


    int ALERT_TYPE = 1;


    ArrayList<loginfo> logholder;
    Context context;

    public logadapter(ArrayList<loginfo> logholder, Context context) {
        this.logholder = logholder;
        this.context = context;
    }

    @NonNull
    @Override
    public logViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_log, parent, false);
        return  new logViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull logViewholder holder, int position) {

        loginfo data = logholder.get(position);

        String alerttype = data.getAlert();
        Float voltage = Float.valueOf(data.getVoltage());
        Float co = Float.valueOf(data.getCo());

        if (alerttype.equals("yes")) {
            holder.background.setBackgroundResource(R.color.red);
        }

        if ( voltage < 7.50 || co > 2.50 ) {
            holder.background.setBackgroundResource(R.color.red);
        }

        holder.date.setText(logholder.get(position).getDate());
        holder.time.setText(logholder.get(position).getTime());
        holder.volatge.setText(logholder.get(position).getVoltage());
        holder.ppm.setText(logholder.get(position).getCo());

    }

    @Override
    public int getItemCount() {
        return logholder.size();
    }

    public class logViewholder extends RecyclerView.ViewHolder{


        RelativeLayout background;
        TextView date, time, volatge, ppm;

        public logViewholder(@NonNull View itemView) {
            super(itemView);

            date= itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            volatge = itemView.findViewById(R.id.voltage);
            ppm = itemView.findViewById(R.id.ppm);
            background = itemView.findViewById(R.id.background);


        }
    }
}
