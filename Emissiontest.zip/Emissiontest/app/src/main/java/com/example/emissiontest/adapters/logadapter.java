package com.example.emissiontest.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.emissiontest.R;
import com.example.emissiontest.models.loginfo;
import com.example.emissiontest.models.vehicleinfomodel;

import java.util.ArrayList;

public class logadapter extends RecyclerView.Adapter<logadapter.logViewholder>{


    ArrayList<loginfo> logholder;
    Context context;

    public logadapter(ArrayList<loginfo> logholder, Context context) {
        this.logholder = logholder;
        this.context = context;
    }

    @NonNull
    @Override
    public logViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_log, parent, false);
        return  new logViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull logViewholder holder, int position) {

        loginfo data = logholder.get(position);

        holder.volatge.setText(logholder.get(position).getVoltage());
        holder.ppm.setText(logholder.get(position).getCo());

    }

    @Override
    public int getItemCount() {
        return logholder.size();
    }

    public class logViewholder extends RecyclerView.ViewHolder{


        TextView volatge, ppm;

        public logViewholder(@NonNull View itemView) {
            super(itemView);

            volatge = itemView.findViewById(R.id.voltage);
            ppm = itemView.findViewById(R.id.ppm);


        }
    }
}
